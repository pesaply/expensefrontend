from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, UserMixin, current_user
from twilio.twiml.messaging_response import MessagingResponse
from google_auth_oauthlib.flow import Flow
import holidays
import os
import pathlib
import requests

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a strong secret key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///calendar.db'  # Use SQLite for simplicity; change as needed
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize Extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Database Models
class Calendar(db.Model):
    __tablename__ = 'calendar'
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(50), unique=True, nullable=False)
    phone = db.Column(db.String(200), nullable=True)
    date = db.Column(db.String(200), nullable=True)
    location = db.Column(db.String(200), nullable=True)
    description = db.Column(db.String(200), nullable=True)
    link = db.Column(db.String(200), nullable=True)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)

# Initialize the database inside an app context
with app.app_context():
    db.create_all()

# Google OAuth Setup
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
client_secrets_file = os.path.join(pathlib.Path(__file__).parent, "client_secrets.json")
flow = Flow.from_client_secrets_file(
    client_secrets_file,
    #scopes=["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email"],
    scopes=["openid", "https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email"],
    redirect_uri="http://127.0.0.1:5000/login/callback"
)

# Tanzanian public holidays
tz_holidays = holidays.Tanzania()

# Flask-Login configuration
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def home():
    calendars = Calendar.query.all()
    return render_template("index.html", calendars=calendars, user=current_user)

@app.route('/login')
def login():
    authorization_url, state = flow.authorization_url()
    session['state'] = state
    return redirect(authorization_url)

@app.route('/login/callback')
def callback():
    flow.fetch_token(authorization_response=request.url)
    credentials = flow.credentials
    request_session = requests.Session()
    request_session.headers.update({'Authorization': f'Bearer {credentials.token}'})
    user_info = request_session.get('https://www.googleapis.com/oauth2/v1/userinfo').json()

    email = user_info['email']
    name = user_info['name']
    user = User.query.filter_by(email=email).first()

    if not user:
        user = User(email=email, name=name)
        db.session.add(user)
        db.session.commit()

    login_user(user)
    return redirect(url_for('home'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/add_calendars', methods=["POST"])
@login_required
def add_calendar():
    keyword = request.form.get("keyword").lower()
    phone = request.form.get('phone')
    description = request.form.get('description')
    location = request.form.get('location')
    date = request.form.get('date')
    link = request.form.get('link')
    if keyword and link:
        if not Calendar.query.filter_by(keyword=keyword).first():
            new_calendar = Calendar(keyword=keyword, link=link, phone=phone, description=description, location=location, date=date)
            db.session.add(new_calendar)
            db.session.commit()
            flash("Calendar added successfully!", "success")
        else:
            flash("Keyword already exists!", "danger")
    else:
        flash("Both keyword and link are required!", "danger")
    return redirect(url_for("home"))

@app.route('/delete_calendar/<int:calendar_id>')
@login_required
def delete_calendar(calendar_id):
    calendar = Calendar.query.get(calendar_id)
    if calendar:
        db.session.delete(calendar)
        db.session.commit()
        flash("Calendar deleted successfully!", "success")
    else:
        flash("Calendar not found!", "danger")
    return redirect(url_for("home"))

@app.route('/whatsapp', methods=["POST"])
def whatsapp_bot():
    # Parse incoming message
    incoming_msg = request.values.get("Body", "").lower()
    response = MessagingResponse()
    msg = response.message()

    # Check for specific keywords in the database
    calendar = Calendar.query.filter_by(keyword=incoming_msg).first()
    if calendar:
        msg.body(f"Here is your schedule for '{incoming_msg}': {calendar.description}, {calendar.date}, {calendar.location}, 'Coordinator Contacts' {calendar.phone}")
    elif "holiday" in incoming_msg:
        # List public holidays in Tanzania
        holidays_list = [f"{date}: {name}" for date, name in tz_holidays.items()]
        holidays_message = "\n".join(holidays_list)
        msg.body(f"Tanzanian public holidays:\n\n{holidays_message}")
    else:
        # Default response
        msg.body("Hi! I can provide calendar links or Tanzanian public holidays. Try typing a keyword for a calendar or 'holiday' for public holidays.")

    return str(response)

if __name__ == "__main__":
    app.run(debug=True)
