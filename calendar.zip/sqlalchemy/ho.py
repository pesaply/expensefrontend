from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from twilio.twiml.messaging_response import MessagingResponse
import holidays

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///calendar.db'
app.config['SECRET_KEY'] = 'iyooyoy9007070'
db = SQLAlchemy(app)

# Database models
class Calendar(db.Model):
    __tablename__ = 'calendar'
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(50), unique=True, nullable=False)
    phone = db.Column(db.String(200), nullable=True)
    date = db.Column(db.String(200), nullable=True)
    location = db.Column(db.String(200), nullable=True)
    description = db.Column(db.String(200), nullable=True)
    link = db.Column(db.String(200), nullable=True)


# Initialize the database inside an app context
with app.app_context():
    db.create_all()

# Tanzanian public holidays
tz_holidays = holidays.Tanzania()

@app.route("/")
def home():
    calendars = Calendar.query.all()
    return render_template("index.html", calendars=calendars)

@app.route("/add_calendars", methods=["POST"])
def add_calendar():
    keyword = request.form.get("keyword").lower()
    phone = request.form.get('phone')
    description = request.form.get('description')
    location = request.form.get('location')
    date = request.form.get('date')
    link = request.form.get('link')
    if keyword and link:
        if not Calendar.query.filter_by(keyword=keyword).first():
            new_calendar = Calendar(keyword=keyword, link=link, phone=phone, description=description, location=location, date=date)
            db.session.add(new_calendar)
            db.session.commit()
            flash("Calendar added successfully!", "success")
        else:
            flash("Keyword already exists!", "danger")
    else:
        flash("Both keyword and link are required!", "danger")
    return redirect(url_for("home"))

@app.route("/delete_calendar/<int:calendar_id>")
def delete_calendar(calendar_id):
    calendar = Calendar.query.get(calendar_id)
    if calendar:
        db.session.delete(calendar)
        db.session.commit()
        flash("Calendar deleted successfully!", "success")
    else:
        flash("Calendar not found!", "danger")
    return redirect(url_for("home"))

@app.route("/whatsapp", methods=["POST"])
def whatsapp_bot():
    # Parse incoming message
    incoming_msg = request.values.get("Body", "").lower()
    response = MessagingResponse()
    msg = response.message()

    # Check for specific keywords in the database
    calendar = Calendar.query.filter_by(keyword=incoming_msg).first()
    if calendar:
        msg.body(f"Here is your schedule for '{incoming_msg}': {calendar.description}, {calendar.date}, {calendar.location}, 'Coordinator Contacts' {calendar.phone}")
    elif "holiday" in incoming_msg:
        # List public holidays in Tanzania
        holidays_list = [f"{date}: {name}" for date, name in tz_holidays.items()]
        holidays_message = "\n".join(holidays_list)
        msg.body(f"Tanzanian public holidays:\n\n{holidays_message}")
    else:
        # Default response
        msg.body("Hi! I can provide calendar links or Tanzanian public holidays. Try typing a keyword for a calendar or 'holiday' for public holidays.")

    return str(response)

if __name__ == "__main__":
    app.run(debug=True)